//Custom js file for project

//notifications alert system


$('.alert').addClass('animated zoomInDown');

setTimeout(function(){$('.alert').removeClass('animated zoomInDown');},3000)
setTimeout(function(){$('.alert').addClass('animated hinge');},4000)



