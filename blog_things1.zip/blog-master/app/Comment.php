<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    //commment 

    protected $fillable=[
    	'body','article_id'
    ];

    public function Article()
    {
    	return $this->belongsTo(Article::class);
    }


}

